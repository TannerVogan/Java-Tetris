import cs5044.tetris.JTetris;

public class Main {

	public static void main(String[] args) {
        JTetris.main(args);

	}

}
